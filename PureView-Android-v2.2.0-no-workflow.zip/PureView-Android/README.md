# PureView for Android · 2.2.0

PureView is a free Android content-protection and digital-wellbeing app derived from the GPL-3.0 NoXXX project. This fork retains the upstream protection engine and adds Ja'fari prayer support, configurable Azan playback, offline games and an Aurora motion-led interface.

## What's new in 2.2.0

- **Aurora visual system:** pearl/indigo/cyan/orchid light theme and ink-navy/cyan/orchid dark theme.
- **Motion design:** spring-animated navigation icons, sliding/fading section transitions, animated shield glow, and existing animated prayer/game hero visuals.
- **Advanced Shield preset:** one tap enables the strict built-in word list, search-box checks, supported URL filtering, family Private DNS requirement, unsupported-browser blocking, private-tab blocking, strict on-device image scanning and tamper protection. It does not hide Android permission controls or prevent the device owner from uninstalling the app. Image scans in messaging/camera apps remain a separate opt-in because they can cause false positives.
- **Azan audio picker:** choose any audio file through Android's system document picker, preview it, restore the bundled Azan, and retain the read permission for scheduled playback.
- **Prayer & Azan:** offline Ja'fari Qum/Tehran profiles, device location or manual coordinates, five daily reminders, selected Azan playback and optional hourly wellbeing notifications.
- **Games:** Memory Matrix, Focus Sprint, Focus Session (25/50-minute timer) and Quick Math run offline with no paid unlocks or subscriptions.

## Prayer-time behavior

The initial fallback location is Wah Cantt, Pakistan (33.7995, 72.8205). Users can grant foreground location permission to calculate times for the current device location or enter coordinates manually. The default Ja'fari Qum profile uses Fajr 16°, Maghrib 4°, Isha 14° and standard one-shadow Asr; the selectable Tehran profile uses Fajr 17.7°, Maghrib 4.5° and Isha 14°. Calculations are offline and use the device time zone. Local mosque calendars can differ by a few minutes, so compare against a trusted local Shia mosque timetable.

Prayer and hourly reminders require Android notification permission. Android 12 and later may require **Alarms & reminders** special access for precise prayer scheduling. Without it, Android can delay inexact reminders. Android battery controls may also defer hourly wellbeing notifications.

## Generate the APK with GitHub Actions

This repository includes `.github/workflows/build.yml`. The workflow runs unit tests and lint, builds a debug APK, and uploads it as a downloadable workflow artifact.

1. Extract this ZIP on your computer.
2. Open the `PureView-Android` folder and upload **the contents of that folder** to the root of your GitHub repository (so `.github`, `app`, `gradle`, `gradlew`, and `settings.gradle.kts` are at repository root).
3. Commit and push to the `main` or `master` branch. You can also open **Actions → Build PureView APK → Run workflow**.
4. Open the completed workflow run, scroll to **Artifacts**, and download `PureView-2.2.0-debug-apk`.
5. Extract the artifact ZIP. The APK inside is `app-debug.apk`.

The GitHub Actions artifact is a debug-signed build intended for testing and direct installation. The workflow calls the wrapper with `bash`, so the build still works when files were uploaded through GitHub web upload and the executable bit on `gradlew` was not retained. For a Play Store or public release, configure your own protected signing key and a separate release workflow. Never commit signing passwords or keystore files to GitHub.

## Build locally

Requirements: JDK 17 and Android SDK Platform 35.

```bash
./gradlew :app:testDebugUnitTest :app:lintDebug :app:assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk`.

## Project identity and licensing

The launcher name is **PureView**. The existing Kotlin package and Android application ID remain `com.noxxx.guard` in this iteration to avoid a risky package migration across services and persisted app state. This fork is derived from the GPL-3.0-licensed [NoXXX source project](https://github.com/Benbone21/NoXXX); retain the included `LICENSE` and comply with GPL-3.0 when redistributing modified source or binaries.

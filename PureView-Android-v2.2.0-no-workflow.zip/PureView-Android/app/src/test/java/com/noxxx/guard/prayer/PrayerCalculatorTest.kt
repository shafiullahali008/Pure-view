package com.noxxx.guard.prayer

import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId

class PrayerCalculatorTest {
    @Test
    fun wahCanttPrayerTimesAreChronologicalInWinter() {
        val times = PrayerCalculator.calculate(
            LocalDate.of(2026, 11, 24),
            latitude = 33.7995,
            longitude = 72.8205,
            zone = ZoneId.of("Asia/Karachi"),
        ).prayers

        assertTrue(times[0].time.isBefore(times[1].time)) // Fajr before sunrise
        assertTrue(times[1].time.isBefore(times[2].time)) // Sunrise before Dhuhr
        assertTrue(times[2].time.isBefore(times[3].time)) // Dhuhr before Hanafi Asr
        assertTrue(times[3].time.isBefore(times[4].time)) // Asr before Maghrib
        assertTrue(times[4].time.isBefore(times[5].time)) // Maghrib before Isha
    }
}

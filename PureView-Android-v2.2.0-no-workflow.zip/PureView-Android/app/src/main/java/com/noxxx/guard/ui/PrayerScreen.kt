package com.noxxx.guard.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.provider.OpenableColumns
import android.os.Build
import android.os.CancellationSignal
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.noxxx.guard.prayer.DailyPrayerTimes
import com.noxxx.guard.prayer.JafariMethod
import com.noxxx.guard.prayer.PrayerAudioService
import com.noxxx.guard.prayer.PrayerCalculator
import com.noxxx.guard.prayer.PrayerPreferences
import com.noxxx.guard.prayer.PrayerScheduler
import com.noxxx.guard.prayer.HourlyNotificationScheduler
import java.time.Duration
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

fun LazyListScope.prayerScreen(refresh: Int) {
    item { PrayerDashboard(refresh) }
}

@Composable
private fun PrayerDashboard(refresh: Int) {
    val context = LocalContext.current
    var settings by remember { mutableStateOf(PrayerPreferences.read(context)) }
    var showLocation by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf("") }

    val azanPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            saveAzanSelection(context, settings, uri.toString()) { updated -> settings = updated }
            notice = "Azan audio changed. The selected file will play at prayer times."
        }
    }
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        notice = if (granted) "PureView notifications enabled" else "Notifications are disabled in Android settings"
    }
    val locationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        val granted = grants[Manifest.permission.ACCESS_FINE_LOCATION] == true || grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            requestCurrentLocation(context) { location ->
                if (location == null) {
                    notice = "No current location fix. Turn on Location and try again, or enter coordinates manually."
                } else {
                    val updated = settings.copy(
                        city = "Current location",
                        latitude = location.latitude,
                        longitude = location.longitude,
                    )
                    settings = updated
                    PrayerPreferences.write(context, updated)
                    notice = "Prayer times updated for your device location"
                }
            }
        } else {
            notice = "Location permission was not granted. You can still enter coordinates manually."
        }
    }

    val exactAlarmAllowed = PrayerScheduler.hasExactAlarmAccess(context)
    LaunchedEffect(settings, exactAlarmAllowed) {
        PrayerScheduler.schedule(context)
        HourlyNotificationScheduler.schedule(context, settings.hourlyNotificationsEnabled)
    }
    val notificationsAllowed = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    val today = LocalDate.now()
    val now = LocalTime.now()
    val daily = remember(today, settings.latitude, settings.longitude, settings.method, refresh) {
        PrayerCalculator.calculate(today, settings.latitude, settings.longitude, method = settings.method)
    }
    val nextToday = daily.next(now)
    val next = nextToday ?: PrayerCalculator.calculate(today.plusDays(1), settings.latitude, settings.longitude, method = settings.method).prayers.first()
    val nextDate = if (nextToday == null) today.plusDays(1) else today
    val target = nextDate.atTime(next.time)
    val remaining = Duration.between(java.time.LocalDateTime.now(), target).let { if (it.isNegative) Duration.ZERO else it }
    val countdown = "%02d:%02d:%02d".format(remaining.toHours(), remaining.toMinutes() % 60, remaining.seconds % 60)
    val format = DateTimeFormatter.ofPattern("hh:mm a", Locale.getDefault())

    fun save(nextSettings: PrayerPreferences) {
        settings = nextSettings
        PrayerPreferences.write(context, nextSettings)
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxWidth()) {
        PrayerHero(city = settings.city, nextName = next.name, countdown = countdown)

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("TODAY'S JA'FARI PRAYER TIMES", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 1.2.sp)
                Text(today.format(DateTimeFormatter.ofPattern("EEEE, d MMMM")), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }
            Text(settings.method.label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
        }
        PrayerTimesCard(daily, now, format)

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(24.dp)),
        ) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Shia calculation profile", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("Choose the Ja'fari method used for Fajr, Maghrib and Isha calculations.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    JafariMethod.entries.forEach { method ->
                        FilterChip(
                            selected = settings.method == method,
                            onClick = { save(settings.copy(method = method)) },
                            label = { Text(method.label) },
                        )
                    }
                }
                Text("Qum is selected by default. Local mosque calendars can differ by a few minutes, so compare once with your trusted local Shia mosque timetable.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(24.dp)),
        ) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.NotificationsActive, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text("Prayer reminders", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(start = 10.dp), fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    Switch(checked = settings.remindersEnabled, onCheckedChange = { enabled ->
                        save(settings.copy(remindersEnabled = enabled))
                        if (enabled && !notificationsAllowed) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                    })
                }
                Text("Receive a notification at each of the five daily prayer times.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.AccessTime, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text("Precise prayer scheduling", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(start = 10.dp))
                    Spacer(Modifier.weight(1f))
                    Text(if (exactAlarmAllowed) "Allowed" else "Optional", color = if (exactAlarmAllowed) Color(0xFF2782A4) else MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
                }
                if (!exactAlarmAllowed) {
                    OutlinedButton(onClick = { PrayerScheduler.openExactAlarmSettings(context) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Filled.Schedule, contentDescription = null)
                        Text("Allow precise prayer reminders", modifier = Modifier.padding(start = 8.dp))
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.AudioFile, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Column(Modifier.weight(1f).padding(start = 10.dp)) {
                        Text("Azan audio", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                        val bundled = PrayerPreferences.uploadedAzanUri(context)
                        val selectedName = remember(settings.azanUri) {
                            azanDisplayName(context, settings.azanUri ?: bundled)
                        }
                        Text(selectedName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                    }
                    Switch(checked = settings.azanEnabled, onCheckedChange = { save(settings.copy(azanEnabled = it)) })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { azanPicker.launch(arrayOf("audio/*")) }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.AudioFile, contentDescription = null)
                        Text("Change audio", modifier = Modifier.padding(start = 7.dp))
                    }
                    if (settings.azanUri != null && settings.azanUri != PrayerPreferences.uploadedAzanUri(context)) {
                        OutlinedButton(onClick = {
                            save(settings.copy(azanUri = PrayerPreferences.uploadedAzanUri(context)))
                            notice = "Bundled Azan restored"
                        }) { Text("Reset") }
                    }
                }
                OutlinedButton(onClick = {
                    val selectedUri = settings.azanUri ?: PrayerPreferences.uploadedAzanUri(context)
                    val play = Intent(context, PrayerAudioService::class.java).apply { data = Uri.parse(selectedUri) }
                    runCatching { ContextCompat.startForegroundService(context, play) }
                        .onFailure { notice = "Could not start Azan playback. Re-select the audio file if its permission expired." }
                }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null)
                    Text("Preview selected Azan", modifier = Modifier.padding(start = 8.dp))
                }
                Text("Choose any audio file from your device. PureView stores its read permission and uses the selected recording for scheduled prayer playback. Your audio stays on this device.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(24.dp)),
        ) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.NotificationsActive, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Column(Modifier.weight(1f).padding(start = 10.dp)) {
                        Text("Hourly PureView check-ins", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("A gentle focus or wellbeing reminder every hour", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = settings.hourlyNotificationsEnabled, onCheckedChange = { enabled ->
                        save(settings.copy(hourlyNotificationsEnabled = enabled))
                        if (enabled && !notificationsAllowed) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                    })
                }
                Text("Android may delay these non-urgent notifications slightly to save battery. You can turn them off here at any time.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(24.dp)),
        ) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(settings.city, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("${"%.4f".format(settings.latitude)}, ${"%.4f".format(settings.longitude)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TextButton(onClick = { showLocation = true }) { Text("Edit") }
                }
                OutlinedButton(onClick = {
                    val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    if (fine || coarse) {
                        requestCurrentLocation(context) { location ->
                            if (location == null) notice = "Could not get a location fix. Turn on Location and try again."
                            else save(settings.copy(city = "Current location", latitude = location.latitude, longitude = location.longitude))
                        }
                    } else {
                        locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                    }
                }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.LocationOn, contentDescription = null)
                    Text("Use my current location", modifier = Modifier.padding(start = 8.dp))
                }
                Text("Location access is only used to calculate prayer times on this device. You can also set coordinates manually.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        if (!notificationsAllowed) {
            OutlinedButton(onClick = { notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS) }, modifier = Modifier.fillMaxWidth()) {
                Text("Allow PureView notifications")
            }
        }
        if (notice.isNotBlank()) {
            Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = RoundedCornerShape(14.dp)) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(notice, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSecondaryContainer, style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { notice = "" }) { Text("Dismiss") }
                }
            }
        }
        Text("Prayer times are calculated offline using the selected Ja'fari profile and your device's local time zone. Local mosque calendars can vary slightly.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }

    if (showLocation) LocationDialog(settings, onDismiss = { showLocation = false }, onSave = { updated -> save(updated); showLocation = false })
}

private fun azanDisplayName(context: Context, value: String): String {
    val bundled = PrayerPreferences.uploadedAzanUri(context)
    if (value == bundled) return "Uploaded Azan recording · bundled"
    val name = runCatching {
        context.contentResolver.query(Uri.parse(value), arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }
    }.getOrNull()
    return name?.takeIf { it.isNotBlank() } ?: "Custom audio selected"
}

private fun saveAzanSelection(context: Context, current: PrayerPreferences, uri: String, onSaved: (PrayerPreferences) -> Unit) {
    val updated = current.copy(azanUri = uri)
    PrayerPreferences.write(context, updated)
    onSaved(updated)
}

@SuppressLint("MissingPermission")
private fun requestCurrentLocation(context: Context, onLocation: (Location?) -> Unit) {
    val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    val providers = if (fine) listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER) else listOf(LocationManager.NETWORK_PROVIDER)
    val provider = providers.firstOrNull { runCatching { manager.isProviderEnabled(it) }.getOrDefault(false) }
    if (provider == null) {
        onLocation(null)
        return
    }
    try {
        if (Build.VERSION.SDK_INT >= 30) {
            manager.getCurrentLocation(provider, CancellationSignal(), ContextCompat.getMainExecutor(context)) { onLocation(it) }
        } else {
            @Suppress("DEPRECATION")
            onLocation(manager.getLastKnownLocation(provider))
        }
    } catch (_: SecurityException) {
        onLocation(null)
    }
}

@Composable
private fun PrayerHero(city: String, nextName: String, countdown: String) {
    val transition = rememberInfiniteTransition(label = "prayer-hero")
    val rotation by transition.animateFloat(0f, 360f, infiniteRepeatable(tween(16_000), RepeatMode.Restart), label = "orb-rotation")
    val pulse by transition.animateFloat(0.94f, 1.04f, infiniteRepeatable(tween(2_400), RepeatMode.Reverse), label = "orb-pulse")
    Box(
        Modifier.fillMaxWidth().shadow(14.dp, RoundedCornerShape(30.dp)).clip(RoundedCornerShape(30.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF15183B), Color(0xFF3540A0), Color(0xFF087F91))))
            .padding(22.dp)
    ) {
        Box(Modifier.align(Alignment.TopEnd).size(140.dp).graphicsLayer(rotationZ = rotation, scaleX = pulse, scaleY = pulse)) {
            Box(Modifier.size(140.dp).clip(CircleShape).background(Brush.radialGradient(listOf(Color(0xFF77DCE8).copy(alpha = 0.72f), Color(0xFFE0A6FF).copy(alpha = 0.28f), Color.Transparent))))
            Box(Modifier.padding(22.dp).size(96.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF77DCE8), Color(0xFFB7B9FF)))).border(1.dp, Color.White.copy(alpha = 0.5f), CircleShape))
        }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("PUREVIEW · PRAYER", color = Color(0xFFB4EAF2), style = MaterialTheme.typography.labelLarge, letterSpacing = 2.sp)
            Text("Next prayer", color = Color.White.copy(alpha = 0.78f), style = MaterialTheme.typography.bodyMedium)
            Text(nextName, color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text(countdown, color = Color(0xFFD4E9FF), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp)
            Text("Remaining · $city", color = Color.White.copy(alpha = 0.72f), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun PrayerTimesCard(daily: DailyPrayerTimes, now: LocalTime, format: DateTimeFormatter) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            daily.prayers.forEachIndexed { index, prayer ->
                val isNext = daily.next(now) == prayer
                Row(Modifier.fillMaxWidth().padding(vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).clip(RoundedCornerShape(13.dp)).background(if (isNext) Color(0xFFE4E5FF) else MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                        Text("${index + 1}", color = if (isNext) Color(0xFF292E89) else MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                    }
                    Text(prayer.name, style = MaterialTheme.typography.bodyLarge, fontWeight = if (isNext) FontWeight.Bold else FontWeight.Medium, modifier = Modifier.padding(start = 14.dp))
                    Spacer(Modifier.weight(1f))
                    Text(prayer.time.format(format), style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold, color = if (isNext) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                    if (isNext) Text("  NEXT", color = Color(0xFF087F91), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
                if (index != daily.prayers.lastIndex) Box(Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)))
            }
        }
    }
}

@Composable
private fun LocationDialog(current: PrayerPreferences, onDismiss: () -> Unit, onSave: (PrayerPreferences) -> Unit) {
    var city by remember { mutableStateOf(current.city) }
    var latitude by remember { mutableStateOf(current.latitude.toString()) }
    var longitude by remember { mutableStateOf(current.longitude.toString()) }
    val validLat = latitude.toDoubleOrNull()?.let { it in -90.0..90.0 } == true
    val validLon = longitude.toDoubleOrNull()?.let { it in -180.0..180.0 } == true
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Prayer location") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(city, { city = it }, label = { Text("City / area") }, singleLine = true)
                OutlinedTextField(latitude, { latitude = it }, label = { Text("Latitude") }, singleLine = true, isError = !validLat)
                OutlinedTextField(longitude, { longitude = it }, label = { Text("Longitude") }, singleLine = true, isError = !validLon)
                Text("Wah Cantt default: 33.7995, 72.8205. Select current location for a GPS fix.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = { Button(enabled = city.isNotBlank() && validLat && validLon, onClick = { onSave(current.copy(city = city.trim(), latitude = latitude.toDouble(), longitude = longitude.toDouble())) }) { Text("Save location") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

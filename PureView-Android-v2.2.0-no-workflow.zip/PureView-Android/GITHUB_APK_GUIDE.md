# Build the PureView APK on GitHub

This source archive intentionally does **not** include an Android GitHub Actions workflow.
The F-Droid metadata YAML under `docs/fdroid/` is retained; do not delete it.

## Upload the project

1. Download and extract `PureView-Android-v2.2.0-no-workflow.zip`.
2. Open the `PureView-Android` folder.
3. Upload the **contents** of that folder to the root of your GitHub repository. The repository root should contain `.github/` (it can be created later), `app/`, `gradle/`, `gradlew`, `build.gradle.kts`, and `settings.gradle.kts`.
4. Commit the source files to the `main` or `master` branch.

## Add the APK workflow separately

1. In the GitHub repository, create the path `.github/workflows/` if it does not exist.
2. Create a file named exactly `pureview-apk.yml` inside that folder.
3. Paste the separately supplied `pureview-apk.yml` workflow file into it and commit the change.
4. Open **Actions** → **Build PureView APK**. A push to `main` or `master` starts the workflow; you can also use **Run workflow**.
5. After a successful run, open the run and download the `PureView-2.2.0-debug-apk` artifact. Extract the downloaded artifact ZIP to get the APK.

The workflow builds the `:app:assembleDebug` task using JDK 17, Android SDK Platform 35, and the Gradle Wrapper already included in this source project. The generated debug APK is for testing, not a Play Store release. A Play Store release needs a properly configured release signing key; never commit a keystore or passwords to the repository.
